# Pin Mapping

Replace this file with your actual CubeMX / hardware allocation.

Suggested sections:

- Sensor name
- STM32 pin
- Peripheral type
- Direction
- Voltage
- Notes
